from config import app
from main import *

if __name__ == "__main__":
    app.run(port=3030, debug=True)