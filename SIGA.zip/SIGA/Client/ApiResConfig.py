Servidor ='190.187.52.107'
ApiRest = 'ApiMovilRMS/Api'

Api= f'http://{Servidor}/{ApiRest}/'
# Api= f'http://{Servidor}/'