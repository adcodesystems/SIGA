class EmpresaItemModel():
    def __init__(self, EmpresaId, Nombre,Ruc):
        self.EmpresaId=EmpresaId
        self.Nombre=Nombre
        self.Ruc=Ruc