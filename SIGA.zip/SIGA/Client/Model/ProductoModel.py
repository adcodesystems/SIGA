class ProductoModel:
  def __init__(self, ProductoId, Nombre):
    self.ProductoId = ProductoId   
    self.Nombre = Nombre