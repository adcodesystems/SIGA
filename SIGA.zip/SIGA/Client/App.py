from InstanceFlask import app
from Controller.EmpresaControlador  import *

if __name__ == "__main__":
    app.run(port=3011, debug=True)


